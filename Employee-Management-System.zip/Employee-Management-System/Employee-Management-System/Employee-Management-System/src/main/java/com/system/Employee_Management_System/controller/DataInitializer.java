package com.system.Employee_Management_System.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.repository.EmployeeRepository;

import jakarta.annotation.PostConstruct;


@Component
public class DataInitializer {

    @Autowired
    private EmployeeRepository employeeRepository;

    @PostConstruct
    public void init() {
        if (employeeRepository.findByEmail("admin@example.com") == null) {
            Employee admin = new Employee();
            admin.setName("Admin");
            admin.setEmail("admin@example.com");
            admin.setPassword("admin123");  
            admin.setRole("ADMIN");
            employeeRepository.save(admin);
        }
    }
}

