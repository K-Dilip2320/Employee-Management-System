package com.system.Employee_Management_System.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.system.Employee_Management_System.entity.Leave;
import com.system.Employee_Management_System.service.LeaveService;

@Controller
@RequestMapping("/api/leaves")
public class LeaveController {

    @Autowired
    private LeaveService leaveService;

    @GetMapping
    public String showLeavesPage(Model model) {
        model.addAttribute("leave", new Leave());
        return "leaves";
    }


    @PostMapping("/apply") 
    public String applyLeave(@RequestParam String employeeId, Leave leave, Model model) { 
    	Leave appliedLeave = leaveService.applyLeave(employeeId, leave); 
    	if (appliedLeave != null) { 
    		model.addAttribute("message", "Leave applied successfully!"); 
    		} else { 
    			model.addAttribute("error", "Failed to apply leave. Employee not found."); 
    			} 
    	return "redirect:/api/employees/leaves?employeeId=" + employeeId; 
    	}

    @PostMapping("/approve/{leaveId}")
    public String approveLeave(@PathVariable String leaveId) {
        leaveService.approveLeave(leaveId);
        return "redirect:/api/admin/manage-leaves";
    }

    @PostMapping("/decline/{leaveId}")
    public String declineLeave(@PathVariable String leaveId) {
        leaveService.declineLeave(leaveId);
        return "redirect:/api/admin/manage-leaves";
    }
}
