package com.system.Employee_Management_System.controller;




import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.repository.EmployeeRepository;
import com.system.Employee_Management_System.service.EmployeeService;
import com.system.Employee_Management_System.service.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
@RequestMapping("/api/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private LeaveService leaveService;

    @GetMapping("/login")
    public String showAdminLoginForm() {
        return "admin-login";
    }

    @PostMapping("/login")
    public String loginAdmin(@RequestParam String email, @RequestParam String password, RedirectAttributes redirectAttributes, Model model) {
        Employee admin = employeeService.loginEmployee(email, password);
        if (admin != null && admin.getRole().equals("ADMIN")) {
            return "redirect:/api/admin/dashboard";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid admin credentials. Please try again.");
            return "redirect:/api/admin/login";
        }
    }

    @GetMapping("/dashboard")
    public String showAdminDashboard(Model model) {
        logger.info("Loading admin dashboard...");
        List<Employee> employees = employeeService.findAllEmployees();
        model.addAttribute("employees", employees);
        model.addAttribute("leaves", leaveService.getAllLeaves());
        return "admin-dashboard";
    }

    @GetMapping("/edit-employee/{id}")
    public String showEditEmployeeForm(@PathVariable String id, Model model, @RequestParam(required = false) String message) {
        logger.info("Editing employee with ID: " + id);
        Employee employee = employeeService.findEmployeeById(id);
        if (employee != null) {
            model.addAttribute("employee", employee);
            if (message != null) {
                model.addAttribute("message", message);
            }
            return "edit-employee";
        } else {
            model.addAttribute("error", "Employee not found.");
            return "redirect:/api/admin/dashboard";
        }
    }

    @PostMapping("/update")
    public String updateEmployeeAdminSide(@ModelAttribute Employee employee, RedirectAttributes redirectAttributes) {
        logger.info("Updating employee with ID: " + employee.getId());
        if (employee.getId() == null) {
            redirectAttributes.addFlashAttribute("error", "Invalid employee ID.");
            return "redirect:/api/admin/dashboard";
        }
        Employee updatedEmployee = employeeService.updateProfile(employee);
        if (updatedEmployee != null) {
            redirectAttributes.addFlashAttribute("message", "Employee updated successfully!");
            return "redirect:/api/admin/edit-employee/" + employee.getId() + "?message=Employee+updated+successfully!";
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to update employee.");
            return "redirect:/api/admin/dashboard";
        }
    }

    @GetMapping("/delete-employee/{id}")
    public String deleteEmployee(@PathVariable String id, RedirectAttributes redirectAttributes) {
        logger.info("Deleting employee with ID: " + id);
        boolean deleted = employeeService.deleteEmployee(id);
        if (deleted) {
            redirectAttributes.addFlashAttribute("message", "Employee deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to delete employee.");
        }
        return "redirect:/api/admin/dashboard";
    }

    @GetMapping("/manage-leaves")
    public String manageLeaves(Model model) {
        logger.info("Managing leaves...");
        model.addAttribute("leaves", leaveService.getAllLeaves());
        return "admin-leaves";
    }
    
    
}




