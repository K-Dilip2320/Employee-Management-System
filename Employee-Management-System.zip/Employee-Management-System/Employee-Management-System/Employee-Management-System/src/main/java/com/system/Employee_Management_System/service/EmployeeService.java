package com.system.Employee_Management_System.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.repository.EmployeeRepository;


@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee registerEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }
    
    public boolean existsByEmail(String email) { 
    	return employeeRepository.findByEmail(email) != null; 
    	}

    public Employee loginEmployee(String email, String password) {
        Employee employee = employeeRepository.findByEmail(email);
        if (employee != null && employee.getPassword().equals(password)) {
            return employee;
        }
        return null;
    }
    
    public Employee findEmployeeById(String employeeId) { 
    	Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId); 
    	return optionalEmployee.orElse(null); 
    	}
    
    public Employee updateProfile(Employee updatedEmployee) {
       
        Employee existingEmployee = employeeRepository.findById(updatedEmployee.getId()).orElse(null);
        if (existingEmployee != null) {
           
            updatedEmployee.setPassword(existingEmployee.getPassword());
            return employeeRepository.save(updatedEmployee);
        }
        return null;
    }

    
    public boolean changePassword(String employeeId, String currentPassword, String newPassword) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        if (employee != null && currentPassword.equals(employee.getPassword())) {
            employee.setPassword(newPassword);
            employeeRepository.save(employee);
            return true;
        }
        return false;
    }
    
    public Employee updateProfileAdminSide(Employee updatedEmployee) {
        Employee existingEmployee = employeeRepository.findById(updatedEmployee.getId()).orElse(null);
        if (existingEmployee != null) {
            existingEmployee.setName(updatedEmployee.getName());
            existingEmployee.setEmail(updatedEmployee.getEmail());
            existingEmployee.setRole(updatedEmployee.getRole());
            return employeeRepository.save(existingEmployee);
        }
        return null;
    }

     
    public List<Employee> findAllEmployees() { 
    	return employeeRepository.findAll(); 
    	}
    
    public boolean deleteEmployee(String employeeId) { 
    	Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId); 
    	if (optionalEmployee.isPresent()) { 
    		employeeRepository.deleteById(employeeId); 
    		return true; 
    		} 
    	return false; 
    	}
    
}
