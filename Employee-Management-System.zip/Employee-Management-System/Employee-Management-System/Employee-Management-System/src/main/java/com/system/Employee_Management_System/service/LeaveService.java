package com.system.Employee_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.entity.Leave;
import com.system.Employee_Management_System.repository.EmployeeRepository;
import com.system.Employee_Management_System.repository.LeaveRepository;

@Service
public class LeaveService {

    @Autowired
    private LeaveRepository leaveRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public Leave applyLeave(String employeeId, Leave leave) {
        leave.setStatus("Pending");
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        if (employee != null) {
            leave.setEmployee(employee);
            return leaveRepository.save(leave);
        }
        return null;
    }

    public List<Leave> getLeavesForEmployee(String employeeId) {
        return leaveRepository.findByEmployeeId(employeeId);
    }

    public List<Leave> getAllLeaves() {
        return leaveRepository.findAll();
    }

    public Leave approveLeave(String leaveId) {
        Leave leave = leaveRepository.findById(leaveId).orElse(null);
        if (leave != null) {
            leave.setStatus("Approved");
            return leaveRepository.save(leave);
        }
        return null;
    }

    public Leave declineLeave(String leaveId) {
        Leave leave = leaveRepository.findById(leaveId).orElse(null);
        if (leave != null) {
            leave.setStatus("Declined");
            return leaveRepository.save(leave);
        }
        return null;
    }
}


