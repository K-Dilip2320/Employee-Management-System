package com.system.Employee_Management_System.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.service.EmployeeService;
import com.system.Employee_Management_System.service.LeaveService;


@Controller
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private LeaveService leaveService;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "register";
    }
    
    @PostMapping("/register")
    public String registerEmployee(Employee employee, RedirectAttributes redirectAttributes) {
        if (employeeService.existsByEmail(employee.getEmail())) {
            redirectAttributes.addFlashAttribute("error", "Email is already in use. Please use a different email address.");
            return "redirect:/api/employees/register";
        }
        employeeService.registerEmployee(employee);
        redirectAttributes.addFlashAttribute("message", "Registration successful! Please log in.");
        return "redirect:/api/employees/login";
    }


    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }
    
    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, RedirectAttributes redirectAttributes, Model model) {
        Employee employee = employeeService.loginEmployee(email, password);
        if (employee != null) {
            if ("ADMIN".equalsIgnoreCase(employee.getRole())) {
                redirectAttributes.addFlashAttribute("error", "Admins cannot log in from this page.");
                return "redirect:/api/employees/login";
            } else {
                model.addAttribute("employee", employee);
                return "redirect:/api/employees/profile?employeeId=" + employee.getId();
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid credentials. Please try again.");
            return "redirect:/api/employees/login";
        }
    }


    @GetMapping("/profile")
    public String showEmployeeProfile(@RequestParam String employeeId, Model model) {
        Employee employee = employeeService.findEmployeeById(employeeId);
        model.addAttribute("employee", employee);
        return "employee-profile";
    }

    @PostMapping("/update-profile")
    public String updateEmployeeProfile(Employee employee, RedirectAttributes redirectAttributes) {
        Employee updatedEmployee = employeeService.updateProfile(employee);
        if (updatedEmployee != null) {
            redirectAttributes.addFlashAttribute("message", "Profile updated successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to update profile.");
        }
        return "redirect:/api/employees/profile?employeeId=" + employee.getId();
    }
    
    @PostMapping("/change-password")
    public String changePassword(@RequestParam String employeeId, @RequestParam String currentPassword, @RequestParam String newPassword, RedirectAttributes redirectAttributes) {
        if (!newPassword.matches("(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}")) {
            redirectAttributes.addFlashAttribute("error", "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
            return "redirect:/api/employees/profile";
        }

        boolean success = employeeService.changePassword(employeeId, currentPassword, newPassword);
        if (success) {
            redirectAttributes.addFlashAttribute("message", "Password changed successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to change password. Please check your current password.");
        }
        return "redirect:/api/employees/profile?employeeId=" + employeeId;
    }


    
    @GetMapping("/leave-status")
    public String showLeaveStatus(@RequestParam String employeeId, Model model) {
        Employee employee = employeeService.findEmployeeById(employeeId);
        model.addAttribute("employee", employee);
        model.addAttribute("leaves", leaveService.getLeavesForEmployee(employeeId));
        return "leave-status";
    }

    @GetMapping("/leaves")
    public String showEmployeeLeaves(@RequestParam String employeeId, Model model) {
        Employee employee = employeeService.findEmployeeById(employeeId);
        model.addAttribute("employee", employee);
        model.addAttribute("leaves", leaveService.getLeavesForEmployee(employeeId));
        return "employee-leaves";
    }

}


