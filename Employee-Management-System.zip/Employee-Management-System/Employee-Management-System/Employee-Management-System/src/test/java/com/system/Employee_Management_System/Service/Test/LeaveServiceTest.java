package com.system.Employee_Management_System.Service.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.entity.Leave;
import com.system.Employee_Management_System.repository.EmployeeRepository;
import com.system.Employee_Management_System.repository.LeaveRepository;
import com.system.Employee_Management_System.service.LeaveService;

class LeaveServiceTest {

    @Mock
    private LeaveRepository leaveRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private LeaveService leaveService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testApplyLeave() {
        String employeeId = "1";
        Leave leave = new Leave();
        Employee employee = new Employee();
        employee.setId(employeeId);

        when(employeeRepository.findById(employeeId)).thenReturn(Optional.of(employee));
        when(leaveRepository.save(leave)).thenReturn(leave);

        Leave result = leaveService.applyLeave(employeeId, leave);

        assertEquals(leave, result);
    }

    @Test
    void testGetLeavesForEmployee() {
        String employeeId = "1";
        Leave leave1 = new Leave();
        Leave leave2 = new Leave();

        when(leaveRepository.findByEmployeeId(employeeId)).thenReturn(Arrays.asList(leave1, leave2));

        List<Leave> result = leaveService.getLeavesForEmployee(employeeId);

        assertEquals(2, result.size());
    }

    @Test
    void testGetAllLeaves() {
        Leave leave1 = new Leave();
        Leave leave2 = new Leave();

        when(leaveRepository.findAll()).thenReturn(Arrays.asList(leave1, leave2));

        List<Leave> result = leaveService.getAllLeaves();

        assertEquals(2, result.size());
    }

    @Test
    void testApproveLeave() {
        String leaveId = "1";
        Leave leave = new Leave();
        leave.setId(leaveId);

        when(leaveRepository.findById(leaveId)).thenReturn(Optional.of(leave));
        when(leaveRepository.save(leave)).thenReturn(leave);

        Leave result = leaveService.approveLeave(leaveId);

        assertEquals("Approved", result.getStatus());
    }

    @Test
    void testDeclineLeave() {
        String leaveId = "1";
        Leave leave = new Leave();
        leave.setId(leaveId);

        when(leaveRepository.findById(leaveId)).thenReturn(Optional.of(leave));
        when(leaveRepository.save(leave)).thenReturn(leave);

        Leave result = leaveService.declineLeave(leaveId);

        assertEquals("Declined", result.getStatus());
    }
}

