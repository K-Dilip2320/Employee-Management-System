package com.system.Employee_Management_System.Controller.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.system.Employee_Management_System.controller.EmployeeController;
import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.entity.Leave;
import com.system.Employee_Management_System.service.EmployeeService;
import com.system.Employee_Management_System.service.LeaveService;



class EmployeeControllerTest {

    @Mock
    private EmployeeService employeeService;

    @Mock
    private LeaveService leaveService;

    @Mock
    private org.springframework.ui.Model model;

    @Mock
    private RedirectAttributes redirectAttributes;

    @InjectMocks
    private EmployeeController employeeController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testShowRegisterForm() {
        String viewName = employeeController.showRegisterForm(model);

        assertEquals("register", viewName);
        verify(model, times(1)).addAttribute(eq("employee"), any(Employee.class));
    }

    @Test
    void testRegisterEmployee() {
        Employee employee = new Employee();
        employee.setEmail("test@example.com");

        when(employeeService.existsByEmail(employee.getEmail())).thenReturn(false);
        when(employeeService.registerEmployee(employee)).thenReturn(employee);

        String viewName = employeeController.registerEmployee(employee, redirectAttributes);

        assertEquals("redirect:/api/employees/login", viewName);
        verify(redirectAttributes, times(1)).addFlashAttribute(eq("message"), eq("Registration successful! Please log in."));
    }

    @Test
    void testLogin() {
        String email = "test@example.com";
        String password = "password";
        Employee employee = new Employee();
        employee.setEmail(email);
        employee.setPassword(password);

        when(employeeService.loginEmployee(email, password)).thenReturn(employee);

        String viewName = employeeController.login(email, password, redirectAttributes, model);

        assertEquals("redirect:/api/employees/profile?employeeId=" + employee.getId(), viewName);
        verify(model, times(1)).addAttribute(eq("employee"), eq(employee));
    }

    @Test
    void testShowEmployeeProfile() {
        String employeeId = "1";
        Employee employee = new Employee();
        employee.setId(employeeId);

        when(employeeService.findEmployeeById(employeeId)).thenReturn(employee);

        String viewName = employeeController.showEmployeeProfile(employeeId, model);

        assertEquals("employee-profile", viewName);
        verify(model, times(1)).addAttribute("employee", employee);
    }

    @Test
    void testChangePassword() {
        String employeeId = "1";
        String currentPassword = "oldPassword";
        String newPassword = "NewPass@123";

        when(employeeService.changePassword(employeeId, currentPassword, newPassword)).thenReturn(true);

        String viewName = employeeController.changePassword(employeeId, currentPassword, newPassword, redirectAttributes);

        assertEquals("redirect:/api/employees/profile?employeeId=" + employeeId, viewName);
        verify(redirectAttributes, times(1)).addFlashAttribute(eq("message"), eq("Password changed successfully!"));
    }

    @Test
    void testShowLeaveStatus() {
        String employeeId = "1";
        Employee employee = new Employee();
        employee.setId(employeeId);

        when(employeeService.findEmployeeById(employeeId)).thenReturn(employee);
        when(leaveService.getLeavesForEmployee(employeeId)).thenReturn(Arrays.asList(new Leave(), new Leave()));

        String viewName = employeeController.showLeaveStatus(employeeId, model);

        assertEquals("leave-status", viewName);
        verify(model, times(1)).addAttribute("employee", employee);
        verify(model, times(1)).addAttribute(eq("leaves"), anyList());
    }
}

