package com.system.Employee_Management_System.Controller.Test;



import com.system.Employee_Management_System.controller.LeaveController;
import com.system.Employee_Management_System.entity.Leave;
import com.system.Employee_Management_System.service.LeaveService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class LeaveControllerTest {

    @Mock
    private LeaveService leaveService;

    @Mock
    private Model model;

    @Mock
    private RedirectAttributes redirectAttributes;

    @InjectMocks
    private LeaveController leaveController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testShowLeavesPage() {
        String viewName = leaveController.showLeavesPage(model);

        assertEquals("leaves", viewName);
        verify(model, times(1)).addAttribute(eq("leave"), any(Leave.class));
    }

    @Test
    void testApplyLeave() {
        String employeeId = "1";
        Leave leave = new Leave();

        when(leaveService.applyLeave(employeeId, leave)).thenReturn(leave);

        String viewName = leaveController.applyLeave(employeeId, leave, model);

        assertEquals("redirect:/api/employees/leaves?employeeId=" + employeeId, viewName);
        verify(model, times(1)).addAttribute(eq("message"), eq("Leave applied successfully!"));
    }

    @Test
    void testApplyLeaveFail() {
        String employeeId = "1";
        Leave leave = new Leave();

        when(leaveService.applyLeave(employeeId, leave)).thenReturn(null);

        String viewName = leaveController.applyLeave(employeeId, leave, model);

        assertEquals("redirect:/api/employees/leaves?employeeId=" + employeeId, viewName);
        verify(model, times(1)).addAttribute(eq("error"), eq("Failed to apply leave. Employee not found."));
    }

    @Test
    void testApproveLeave() {
        String leaveId = "1";

        String viewName = leaveController.approveLeave(leaveId);

        assertEquals("redirect:/api/admin/manage-leaves", viewName);
        verify(leaveService, times(1)).approveLeave(leaveId);
    }

    @Test
    void testDeclineLeave() {
        String leaveId = "1";

        String viewName = leaveController.declineLeave(leaveId);

        assertEquals("redirect:/api/admin/manage-leaves", viewName);
        verify(leaveService, times(1)).declineLeave(leaveId);
    }
}
