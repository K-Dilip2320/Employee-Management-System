package com.system.Employee_Management_System.Service.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.repository.EmployeeRepository;
import com.system.Employee_Management_System.service.EmployeeService;

class EmployeeServiceTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeService employeeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterEmployee() {
        Employee employee = new Employee();
        when(employeeRepository.save(employee)).thenReturn(employee);

        Employee result = employeeService.registerEmployee(employee);

        assertEquals(employee, result);
        verify(employeeRepository, times(1)).save(employee);
    }

    @Test
    void testLoginEmployee() {
        String email = "test@example.com";
        String password = "password";
        Employee employee = new Employee();
        employee.setEmail(email);
        employee.setPassword(password);

        when(employeeRepository.findByEmail(email)).thenReturn(employee);

        Employee result = employeeService.loginEmployee(email, password);

        assertEquals(employee, result);
    }

    @Test
    void testFindEmployeeById() {
        String id = "1";
        Employee employee = new Employee();
        employee.setId(id);

        when(employeeRepository.findById(id)).thenReturn(Optional.of(employee));

        Employee result = employeeService.findEmployeeById(id);

        assertEquals(employee, result);
    }

    @Test
    void testUpdateProfile() {
        Employee employee = new Employee();
        employee.setId("1");
        employee.setPassword("oldPassword");

        when(employeeRepository.findById(employee.getId())).thenReturn(Optional.of(employee));
        when(employeeRepository.save(employee)).thenReturn(employee);

        Employee result = employeeService.updateProfile(employee);

        assertEquals(employee, result);
    }

    @Test
    void testChangePassword() {
        Employee employee = new Employee();
        employee.setId("1");
        employee.setPassword("oldPassword");

        when(employeeRepository.findById(employee.getId())).thenReturn(Optional.of(employee));
        when(employeeRepository.save(employee)).thenReturn(employee);

        boolean result = employeeService.changePassword(employee.getId(), "oldPassword", "newPassword");

        assertTrue(result);
        assertEquals("newPassword", employee.getPassword());
    }

    @Test
    void testFindAllEmployees() {
        Employee employee1 = new Employee();
        Employee employee2 = new Employee();
        when(employeeRepository.findAll()).thenReturn(Arrays.asList(employee1, employee2));

        List<Employee> result = employeeService.findAllEmployees();

        assertEquals(2, result.size());
    }

    @Test
    void testDeleteEmployee() {
        String id = "1";
        Employee employee = new Employee();
        employee.setId(id);

        when(employeeRepository.findById(id)).thenReturn(Optional.of(employee));
        doNothing().when(employeeRepository).deleteById(id);

        boolean result = employeeService.deleteEmployee(id);

        assertTrue(result);
        verify(employeeRepository, times(1)).deleteById(id);
    }
}
