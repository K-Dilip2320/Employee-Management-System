package com.system.Employee_Management_System.Controller.Test;



import com.system.Employee_Management_System.controller.AdminController;
import com.system.Employee_Management_System.entity.Employee;
import com.system.Employee_Management_System.entity.Leave;
import com.system.Employee_Management_System.service.EmployeeService;
import com.system.Employee_Management_System.service.LeaveService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class AdminControllerTest {

    @Mock
    private EmployeeService employeeService;

    @Mock
    private LeaveService leaveService;

    @Mock
    private Model model;

    @Mock
    private RedirectAttributes redirectAttributes;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testShowAdminLoginForm() {
        String viewName = adminController.showAdminLoginForm();

        assertEquals("admin-login", viewName);
    }

    @Test
    void testLoginAdmin() {
        String email = "admin@example.com";
        String password = "admin123";
        Employee admin = new Employee();
        admin.setEmail(email);
        admin.setPassword(password);
        admin.setRole("ADMIN");

        when(employeeService.loginEmployee(email, password)).thenReturn(admin);

        String viewName = adminController.loginAdmin(email, password, redirectAttributes, model);

        assertEquals("redirect:/api/admin/dashboard", viewName);
    }

    @Test
    void testShowAdminDashboard() {
        Employee employee1 = new Employee();
        Employee employee2 = new Employee();
        when(employeeService.findAllEmployees()).thenReturn(Arrays.asList(employee1, employee2));
        when(leaveService.getAllLeaves()).thenReturn(Arrays.asList(new Leave(), new Leave()));

        String viewName = adminController.showAdminDashboard(model);

        assertEquals("admin-dashboard", viewName);
        verify(model, times(1)).addAttribute(eq("employees"), anyList());
        verify(model, times(1)).addAttribute(eq("leaves"), anyList());
    }

    @Test
    void testShowEditEmployeeForm() {
        String id = "1";
        Employee employee = new Employee();
        employee.setId(id);

        when(employeeService.findEmployeeById(id)).thenReturn(employee);

        String viewName = adminController.showEditEmployeeForm(id, model, null);

        assertEquals("edit-employee", viewName);
        verify(model, times(1)).addAttribute("employee", employee);
    }

    @Test
    void testUpdateEmployeeAdminSide() {
        Employee employee = new Employee();
        employee.setId("1");

        when(employeeService.updateProfile(employee)).thenReturn(employee);

        String viewName = adminController.updateEmployeeAdminSide(employee, redirectAttributes);

        assertEquals("redirect:/api/admin/edit-employee/" + employee.getId() + "?message=Employee+updated+successfully!", viewName);
        verify(redirectAttributes, times(1)).addFlashAttribute(eq("message"), eq("Employee updated successfully!"));
    }

    @Test
    void testDeleteEmployee() {
        String id = "1";

        when(employeeService.deleteEmployee(id)).thenReturn(true);

        String viewName = adminController.deleteEmployee(id, redirectAttributes);

        assertEquals("redirect:/api/admin/dashboard", viewName);
        verify(redirectAttributes, times(1)).addFlashAttribute(eq("message"), eq("Employee deleted successfully!"));
    }

    @Test
    void testManageLeaves() {
        when(leaveService.getAllLeaves()).thenReturn(Arrays.asList(new Leave(), new Leave()));

        String viewName = adminController.manageLeaves(model);

        assertEquals("admin-leaves", viewName);
        verify(model, times(1)).addAttribute(eq("leaves"), anyList());
    }
}
